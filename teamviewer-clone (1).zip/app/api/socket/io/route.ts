import { type NextRequest, NextResponse } from "next/server"

// Esta es una implementación básica para Vercel
// En Vercel, los WebSockets tradicionales no funcionan igual que en servidores dedicados
export async function GET(request: NextRequest) {
  return NextResponse.json({
    message: "Socket.IO endpoint - Vercel no soporta WebSockets persistentes",
    developer: "Armando Ovalle",
    whatsapp: "+57 305 289 1719",
    recommendation: "Usar WhatsApp para asistencia directa: 'hola quiero asistencia'",
    status: "limited_functionality",
    timestamp: new Date().toISOString(),
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Log básico para debugging
    console.log("Socket.IO request:", body)

    return NextResponse.json({
      message: "Solicitud recibida",
      developer: "Armando Ovalle",
      whatsapp: "+57 305 289 1719",
      data: body,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: "Error procesando solicitud",
        developer: "Armando Ovalle",
        whatsapp: "+57 305 289 1719",
        message: "Contacta por WhatsApp para asistencia",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
