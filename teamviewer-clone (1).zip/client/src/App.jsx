import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { Toaster } from "react-hot-toast"
import Layout from "./components/common/Layout"
import Home from "./pages/Home"
import Demo from "./pages/Demo"
import Preview from "./pages/Preview"
import NotFound from "./pages/NotFound"

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route
            path="/"
            element={
              <Layout>
                <Home />
              </Layout>
            }
          />
          <Route
            path="/demo"
            element={
              <Layout>
                <Demo />
              </Layout>
            }
          />
          <Route path="/preview" element={<Preview />} />
          <Route
            path="*"
            element={
              <Layout>
                <NotFound />
              </Layout>
            }
          />
        </Routes>

        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: "#363636",
              color: "#fff",
            },
          }}
        />
      </div>
    </Router>
  )
}

export default App
